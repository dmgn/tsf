module.exports ={
    aws_bucket: process.env.S3_BUCKET,
    aws_key: process.env.AWS_ACCESS_KEY_ID,
    aws_secret: process.env.AWS_SECRET_ACCESS_KEY
}